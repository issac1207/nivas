﻿using Microsoft.EntityFrameworkCore;

namespace OnlineExamAPI.Models
{
    public class ExamDBContext : DbContext
    {
        public ExamDBContext(DbContextOptions<ExamDBContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Role>().HasData(
                new Role { RoleId = 1, RoleName = "Admin" },
                new Role { RoleId = 2, RoleName = "Users" });
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserName = "admin@gmail.com",
                    FirstName = "Exam",
                    LastName = "Admin",
                    Age = 29,
                    Gender = "Male",
                    Password = "admin123",
                    Address = "Korea",
                    PhoneNumber = "987654321",
                    RoleId = 1
                });
            modelBuilder.Entity<Choice>().HasData(
                new Choice { ChoiceId = 1, ChoiceName = "C", Level = 1 },
                new Choice { ChoiceId = 2, ChoiceName = "C", Level = 2 },
                new Choice { ChoiceId = 3, ChoiceName = "C", Level = 3 },
                new Choice { ChoiceId = 4, ChoiceName = "CPP", Level = 1 },
                new Choice { ChoiceId = 5, ChoiceName = "CPP", Level = 2 },
                new Choice { ChoiceId = 6, ChoiceName = "CPP", Level = 3 },
                new Choice { ChoiceId = 7, ChoiceName = "C#", Level = 1 },
                new Choice { ChoiceId = 8, ChoiceName = "C#", Level = 2 },
                new Choice { ChoiceId = 9, ChoiceName = "C#", Level = 3 }
                );
            base.OnModelCreating(modelBuilder);
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Choice> Choices { get; set; }
        public DbSet<Exam> Exams { get; set; }
        public DbSet<Question> Questions { get; set; }
    }
}
