﻿using OnlineExamAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace OnlineExamAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminFunctionController : ControllerBase
    {
        ExamDBContext db = null;
        public AdminFunctionController(ExamDBContext context)
        {
            db = context;
        }
        [Route("ViewUsers")]
        [HttpGet]
        public IActionResult ViewUsers()
        {
            var users = db.Users.ToList();
            //var users = (from u in db.Users where u.RoleId !=).FirstOrDefault().ToList();
            return Ok(users);
        }
        [Route("AddQuestion")]
        [HttpPost]
        public IActionResult AddQuestion(Question question)
        {
            if(question == null)
            {
                return BadRequest();
            }
            if(ModelState.IsValid)
            {
                db.Questions.Add(question);
                db.SaveChanges();
                return Ok(question);
            }
            return Ok();
        }
        [Route("ViewQuestion")]
        [HttpPost]
        public IActionResult ViewQuestion(int id)
        {
            //var questions = db.Questions.ToList();
            //return Ok(questions);
            var questions = from q in db.Questions
                            where q.ExamId == id
                            select q;
            return Ok(questions.ToList());
        }
        [Route("DeleteQuestion")]
        [HttpPost]
        public IActionResult DeleteQuestion(int id)
        {
            var questions = db.Questions.Find(id);
            if(questions == null)
            {
                return BadRequest();
            }
            else
            {
                db.Questions.Remove(questions);
                db.SaveChanges();
            }
            return Ok();
        }
        [Route("UpdateQuestion")]
        [HttpPost]
        public IActionResult UpdateQuestions(int id,Question modifiedquestion)
        {
            var questions=db.Questions.Find(id);
            if(questions!=null)
            {
                questions.QuestionText = modifiedquestion.QuestionText;
                questions.Option1 = modifiedquestion.Option1;
                questions.Option2=modifiedquestion.Option2;
                questions.Option3=modifiedquestion.Option3;
                questions.Option4=modifiedquestion.Option4;
                questions.Answer = modifiedquestion.Answer;
                questions.ExamId=modifiedquestion.ExamId;
                db.SaveChanges();
                return Ok(questions);
            }
            return Ok(questions);
        }
    }
}
