﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Diagnostics;
using System.Text;
using OnlineExamMVC.Models;

namespace OnlineExamMVC.Controllers
{
    public class LoginUserController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]

        public IActionResult Login(Login user)

        {

            

                using (var httpClient = new HttpClient())

                {

                    StringContent content

                       = new StringContent(JsonConvert.SerializeObject(user),

                           Encoding.UTF8, "application/json");

                    //replace the portnumber with the Ocelot Gateway portnumber

                    string url = "http://localhost:9748/api/Login/LoginUser";

                    using (var response = httpClient.PostAsync(url, content))

                    {

                        if (response.Result.IsSuccessStatusCode)

                        {

                        // ViewData["Message"] = "Login Success";

                        //var responseText = response.Result.Content.ReadAsStringAsync().Result;

                        // return RedirectToPage("Stores","Admin"/* new { m = responseText }*/);

                        if (user.UserName == "admin@gmail.com" && user.Password == "admin123")

                            {

                                return RedirectToAction("Index", "Exam");
                                
                            }

                            else

                            {

                            // ViewData["Message"] = "Invalid Admin";
                            return RedirectToAction("Index", "LoginUser");

                        }

                        }

                        else

                        {

                            ViewData["message"] = "invalid login credentials..";

                        }

                        // return RedirectToAction("Index");

                    }

                }

            

            return View();

        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]

        public IActionResult Error()

        {

            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });

        }

        public IActionResult Register()

        {

            return View();

        }

        [HttpPost]
        public async Task<IActionResult> Register(UserRegister user)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var httpClient = new HttpClient())
                    {
                        StringContent content = new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json");
                        using (var response
                        = await httpClient.PostAsync("http://localhost:9748/api/Login/UserRegister/", content))
                        {
                            ViewData["Message"] = "You have successfully registered.You can login now...";
                        }
                    }
                }
                return View("Index");
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }
    }
}

